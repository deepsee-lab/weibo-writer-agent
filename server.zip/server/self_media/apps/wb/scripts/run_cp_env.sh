cp .env.example .env
