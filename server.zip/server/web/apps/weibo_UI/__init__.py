# -*- coding: utf-8 -*-
# Local application/library specific imports.
from apps.weibo_UI.views import bp
