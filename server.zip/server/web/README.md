# web

## 新增蓝图

新增蓝图可以参考`server/flask_demo/README.md`
