# -*- coding: utf-8 -*-
# Related third party imports.
from flask_sqlalchemy import SQLAlchemy

# DB
db = SQLAlchemy()
