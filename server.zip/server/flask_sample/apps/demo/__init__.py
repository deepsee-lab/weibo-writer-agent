# -*- coding: utf-8 -*-
# Local application/library specific imports.
from apps.demo.views import bp
