pkill -f supervisor
sleep 10
supervisord -c supervisor.conf